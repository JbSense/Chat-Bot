// Import dependências
import axios from 'axios';
import React, { Component } from 'react';

// Import css
import '../styles/components/Chat.css'

// Import components
import Message from './Message';

// Estado inicial da aplicação
const initialState = {
    start: true,
    styles: {
        background_color: '',
        me_color: '',
        bot_color: ''
    },
    messages: [],
    writing: '',
    newMessage: false,
    addComand: false,
    newComand: {
        "request": "",
        "response": ""
    }
}

class Chat extends Component {

    /**
     * Seta o estado inicial 
     */
    state = { ...initialState }

    /**
     * Chamada sempre que a página é carrega, chama a função updateMessages
     * para exibir o histórico de mensagens
     */
    start() {
        if(this.state.start === true ) { 
            this.api('get', 'get-messages').then(data => {
                this.updateMessages(data.data)
                this.downScreem()
            })

            this.setState({ start: false })
        }
    }

    /* 
     * Rola a tela para baixo sempre que uma mensagem é salva
     *
     */
    downScreem() {
        const scrolling = document.querySelector('.scrolling')
        scrolling.scrollTo(0, scrolling.scrollHeight)
    }

    /**
     * Função usada para consumir o backend
     * 
     * @param {string} method -  o método que será usado na requisição
     * @param {string} where - função da api que será usada
     * @param {json} obj - json que será cadastrado no banco caso seja um cadastro
     * @returns o data da requisição
     */
    api(method, where, obj = null) {
        const config = {
            method: method,
            url: `http://localhost:8080/api/${where}`,
            data: obj
        }

        return axios(config).then(response => response.data)
    }

    /**
     * Atualiza as o state.messages
     */
    updateMessages(obj) {
        const messages = []
        for(let x in obj) {
            messages.unshift(obj[x])
        }

        this.setState({ messages: messages })
        this.downScreem()
        this.setState({ newMessage: false })
    }

    /**
     * Obtém os dados da máquina
     */
    getSystemInformations(msg) {
        this.api('get', 'get-system').then(data => {
            const so = `${data.data.platform} ${data.data.architecture[0]} ${data.data.architecture[1]}`

            if(msg == "system ip") { return this.saveMessage("bot", data.data.ip) }
            if(msg == "system so") { return this.saveMessage("bot", so) }
            if(msg == "system ip publico") {
                const config = {
                    method: "get",
                    url: "https://api.ipify.org/?format=json"
                }

                axios(config).then(response => {
                    this.saveMessage("bot", response.data.ip)
                })
            }
        })
    }

    /**
     * Lista os comandos existentes
     */
    listComands() {
        this.api('get', 'get-comands').then(data => {
            const comands = []
            for(let x in data.data) {
                comands.unshift(data.data[x])
            }

            for(let x in comands) {
                this.saveMessage("bot", comands[x].request)
            }
        })
    }

    /**
     * Renderiza as imagens para exibir na tela
     * 
     * @returns a mensagem chamando o component Message 
     */
    renderMessages() {
        const messages = []
        for(let x in this.state.messages) {
            messages.unshift(this.state.messages[x])
        }

        return(
            messages.map((key) => {
                return <Message user={key.user} message={key.message} />
            })
        )
    }

    /**
     * Adiciona o que está sendo escrito no state.writing
     *
     * @param {event} event - recebe o evento que chamou a function
     */
    writing(event) {
        if(this.state.newMessage === false) this.setState({ writing: event.target.value })
        return
    }

    /*
     * Limpa o writing
     */
    clear() {
        this.setState({ writing: "" })
    }

    /**
     * Valida se a tecla pressionada foi (Enter)
     * Caso a validação seja true, chama a funtion saveMessage
     * 
     * @param {event} event - recebe o evento, tecla que foi pressionada
     */
    enter(event) {
        if(event.code === "Enter") this.newMessage()
    }

    /**
     * Salva uma mensagem no banco e no final chama a função updateMessages 
     * para atualizar as mensagens na tela
     * 
     * @param {string} user - indica de quem é a mensagem (client ou bot)
     */
    saveMessage(user, message) {
        const body = new FormData

        body.append('message', message)
        body.append('user', user)

        this.api('post', 'create-message', body).then(data => {
            this.updateMessages(data.data)
            this.clear()
        })
    }

    /**
     * Chamado quando uma nova mensagem será enviada do lado cliente
     * chama função saveMessages para salvar a mensagem atual e depois
     * a função getResponse para exbir a resposta
     */
    newMessage() {
        this.setState({ newMessage: false })
        if(this.state.writing === "") return

        this.saveMessage("client", this.state.writing)
        
        const msg = this.formatMessage(this.state.writing)
        if(msg.includes("system")) { return setTimeout(() => { this.getSystemInformations(msg) }, 500) }
        if(msg === "listar comandos") { return setTimeout(() => { this.listComands(msg) }, 500) }

        if(this.state.addComand === true) { return this.addComand(msg) }
        if(msg === "adicionar comando") { 
            this.setState({ addComand: true })
            return setTimeout(() => { this.saveMessage("bot", "Ok, digite o comando") }, 500)
        }

        this.getResponse(this.state.writing)
    }

    /**
     * Obtém a resposta para a mensagem enviada e chama a função
     * saveMessages para salvar a resposta no banco
     */
    getResponse(message) {
        const body = new FormData
        body.append('request', message)

        this.api('post', 'get-response', body).then(data => {
            if(data.data.response === null) {
                return setTimeout(() => {
                    this.saveMessage("bot", "Infelizmente não sou capaz de lhe responder. Para adicionar um comando, digite 'adicionar comando'")
                }, 500)
            }

            setTimeout(() => {
                this.saveMessage("bot", data.data.response)
            }, 500)
        })
    }

    /**
     * Adiciona um novo comando
     * @param {string} message - mensagem que será setada em request ou response
     * @returns 
     */
    addComand(message) {
        if(this.state.addComand === true) {
            let comand = this.state.newComand

            if(message === "adicionar comando") { 
                setTimeout(() => { this.saveMessage("bot", "Infelizmente não posso aceitar esse comando") }, 500)
                return this.setState({ addComand: false })
            }

            if(this.state.newComand.request === "") {
                comand.request = message
                this.setState({ newComand: comand })
                return setTimeout(() => { this.saveMessage("bot", "Agora a resposta") }, 500)
            } else {
                this.setState({ newComand: comand.response = message })

                const body = new FormData

                body.append('request', this.state.newComand.request)
                body.append('response', this.state.newComand.response)

                this.api("post", "create-comand", body).then(data => {
                    this.setState({ newComand: {
                        "request": "",
                        "response": ""
                    } })

                    this.setState({ addComand: false })

                    if(data.status === 400) {
                        return setTimeout(() => { this.saveMessage("bot", "Esse comando já existe, digite 'listar comandos' para ver os comandos existente") }, 500)
                    }
                    
                    return setTimeout(() => { this.saveMessage("bot", "Comando aprendido") }, 500)
                })

            }
        }
    }

    /* 
     * Faz a formatação da mensagem e salva no state.writing
     *
     */
    formatMessage(message) {
        var words = {
            a : /[\xE0-\xE6]/g,
            e : /[\xE8-\xEB]/g,
            i : /[\xEC-\xEF]/g,
            o : /[\xF2-\xF6]/g,
            u : /[\xF9-\xFC]/g,
            c : /\xE7/g,
            n : /\xF1/g
        };
        
        let msg = message.toLowerCase()

        for ( var x in words ) {
            msg = msg.replace( words[x], x );
        }
    
        return msg
    }

    /**
     * Função utiliza para testes
     */
    test() {
        //
    }

    render() {
        return(
            <div className='chat' onLoad={this.start()}>
                <div className='contact'>
                    <p className='first-letter-name'>W</p>
                    <p className='contact-name'>Windows</p>
                </div>

                <div className='messages'>
                    <div className="scrolling">
                        {this.renderMessages()}
                    </div>
                </div>

                <div className='writer'>
                    <input type="text" name="message" id="writer" placeholder="Digite..." value={this.state.writing} onChange={ e => this.writing(e) } onKeyDown={(e) => this.enter(e)}/>
                </div>
            </div>
        )
    }
}

export default Chat